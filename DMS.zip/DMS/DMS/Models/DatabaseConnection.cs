﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DMS.Models
{
    public static class DatabaseConnection
    {
        public static string ConnectionString { get; set; }


    }
}
