﻿using System;
using System.Collections.Generic;

namespace DMS.Models
{
    public class ProjectDropdown
    {
        public int ProjectID { get; set; }
        public string ProjectNo { get; set; }
    }


}
