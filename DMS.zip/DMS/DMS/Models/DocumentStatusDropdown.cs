﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DMS.Models
{
    public class DocumentStatusDropdown
    {
           public int DocumentStatusID { get; set; }
           public string StatusDesc { get; set; }
    }
}
